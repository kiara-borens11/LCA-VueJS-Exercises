<template>
  <div class="container">
    <h1>FlexZone Fitness Scheduler</h1>

    <AddClassForm @add-session="addSession" />

    <h2>Total Classes: {{ totalSessions }}</h2>

    <p v-if="sessions.length === 0">
      No sessions scheduled.
    </p>

    <ClassList
      v-else
      :sessions="sessions"
      @delete-session="deleteSession"
    />
  </div>
</template>

<script setup>
import { ref, computed } from "vue"
import AddClassForm from "./components/AddClassForm.vue"
import ClassList from "./components/ClassList.vue"

const sessions = ref([])

const addSession = (session) => {
  sessions.value.push({
    id: Date.now(),
    ...session
  })
}

const deleteSession = (id) => {
  sessions.value = sessions.value.filter(
    session => session.id !== id
  )
}

const totalSessions = computed(() => sessions.value.length)
</script>