<template>

<div class="cards">

<div
v-for="session in sessions"
:key="session.id"
class="card"
>

<h3>{{ session.name }}</h3>

<p><strong>Coach:</strong> {{ session.coach }}</p>

<p><strong>Date:</strong> {{ session.date }}</p>

<p><strong>Time:</strong> {{ session.time }}</p>

<p><strong>Capacity:</strong> {{ session.capacity }}</p>

<button @click="$emit('delete-session', session.id)">
Delete
</button>

</div>

</div>

</template>

<script setup>

defineProps({
sessions: Array
})

defineEmits([
"delete-session"
])

</script>