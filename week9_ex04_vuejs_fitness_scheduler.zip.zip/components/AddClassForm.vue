<template>
  <form @submit.prevent="submitForm">

    <input
      v-model="name"
      type="text"
      placeholder="Class Name"
    />

    <input
      v-model="coach"
      type="text"
      placeholder="Coach"
    />

    <input
      v-model="date"
      type="date"
    />

    <input
      v-model="time"
      type="time"
    />

    <input
      v-model="capacity"
      type="number"
      placeholder="Capacity"
    />

    <button>Add Class</button>

    <p class="error">{{ error }}</p>

  </form>
</template>

<script setup>
import { ref } from "vue"

const emit = defineEmits(["add-session"])

const name = ref("")
const coach = ref("")
const date = ref("")
const time = ref("")
const capacity = ref("")
const error = ref("")

const submitForm = () => {

  if (
    !name.value ||
    !coach.value ||
    !date.value ||
    !time.value ||
    !capacity.value
  ) {
    error.value = "Please fill in all fields."
    return
  }

  emit("add-session", {
    name: name.value,
    coach: coach.value,
    date: date.value,
    time: time.value,
    capacity: capacity.value
  })

  name.value = ""
  coach.value = ""
  date.value = ""
  time.value = ""
  capacity.value = ""
  error.value = ""
}
</script>