<template>
  <div>

    <Header :wishlistCount="wishlist.length"/>

    <div class="course-container">

      <CourseCard
        v-for="course in courses"
        :key="course.id"
        :course="course"
        @saveCourse="saveCourse"
      />

    </div>

  </div>
</template>

<script setup>

import { ref } from 'vue'
import Header from './components/Header.vue'
import CourseCard from './components/CourseCard.vue'

const wishlist = ref([])

const courses = ref([

{
id:1,
title:"Italian Pasta Masterclass",
chef:"Chef Marco",
price:450,
level:"Beginner",
available:true
},

{
id:2,
title:"French Pastries",
chef:"Chef Sophie",
price:600,
level:"Advanced",
available:false
},

{
id:3,
title:"Sushi Essentials",
chef:"Chef Ken",
price:700,
level:"Intermediate",
available:true
},

{
id:4,
title:"Mexican Street Food",
chef:"Chef Carlos",
price:500,
level:"Beginner",
available:true
}

])

function saveCourse(course){

if(!wishlist.value.find(item=>item.id===course.id)){
wishlist.value.push(course)
}

}

</script>