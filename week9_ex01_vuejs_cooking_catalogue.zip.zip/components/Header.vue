<template>

<header>

<h1>Cooking Masterclass</h1>

<div class="wishlist">

❤️ Wishlist: {{ wishlistCount }}

</div>

</header>

</template>

<script setup>

defineProps({

wishlistCount:Number

})

</script>