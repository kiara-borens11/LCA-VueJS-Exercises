<template>

<div class="card">

<h2>{{ course.title }}</h2>

<p><strong>Chef:</strong> {{ course.chef }}</p>

<p><strong>Level:</strong> {{ course.level }}</p>

<p><strong>Price:</strong> R{{ course.price }}</p>

<p
v-if="course.available"
class="available"
>

Available

</p>

<p
v-else
class="soldout"
>

Sold Out

</p>

<button
@click="save"
:disabled="!course.available"
>

Save to Wishlist

</button>

</div>

</template>

<script setup>

const props=defineProps({

course:Object

})

const emit=defineEmits(['saveCourse'])

function save(){

emit('saveCourse',props.course)

}

</script>