<template>

<div class="card" :class="{featured:ticket.featured}">

    <h2>{{ticket.name}}</h2>

    <h3>R{{ticket.price}}</h3>

    <p>{{ticket.description}}</p>

    <ul>

        <li
        v-for="benefit in ticket.benefits"
        :key="benefit"
        >
        ✔ {{benefit}}
        </li>

    </ul>

    <button @click="$emit('toggleFavourite',ticket.id)">

        {{ticket.favourite ? "❤️ Favourite" : "🤍 Add Favourite"}}

    </button>

    <button class="buy">
        Buy Now
    </button>

</div>

</template>

<script setup>

defineProps({
    ticket:Object
})

defineEmits(["toggleFavourite"])

</script>