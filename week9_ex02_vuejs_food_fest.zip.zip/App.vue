<template>
  <div class="container">

    <header class="hero">
      <h1>Cape Town Food Fest 2026</h1>
      <p>
        Enjoy amazing food, live music and unforgettable experiences.
        Choose your perfect ticket package below.
      </p>
    </header>

    <div class="ticket-container">

      <TicketCard
        v-for="ticket in sortedTickets"
        :key="ticket.id"
        :ticket="ticket"
        @toggleFavourite="toggleFavourite"
      />

    </div>

  </div>
</template>

<script setup>

import { ref, computed } from "vue";
import TicketCard from "./components/TicketCard.vue";

const tickets = ref([
  {
    id:1,
    name:"Bronze",
    price:150,
    description:"Perfect for casual visitors.",
    benefits:[
      "General Entry",
      "Food Stalls",
      "Live Music"
    ],
    featured:false,
    favourite:false
  },

  {
    id:2,
    name:"Silver",
    price:300,
    description:"Best value package.",
    benefits:[
      "Priority Entry",
      "VIP Seating",
      "Free Drink"
    ],
    featured:true,
    favourite:false
  },

  {
    id:3,
    name:"Gold",
    price:500,
    description:"Ultimate festival experience.",
    benefits:[
      "Backstage Access",
      "Meet the Chefs",
      "Unlimited Drinks"
    ],
    featured:false,
    favourite:false
  }
]);

const toggleFavourite = (id)=>{

  const ticket = tickets.value.find(t=>t.id===id);

  ticket.favourite=!ticket.favourite;

}

const sortedTickets = computed(()=>{

  return [...tickets.value].sort((a,b)=>a.price-b.price);

})

</script>