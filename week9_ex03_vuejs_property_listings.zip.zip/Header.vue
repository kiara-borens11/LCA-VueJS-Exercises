<template>

<header>

<h1>{{ title }}</h1>

<p>{{ count }} Active Listings</p>

</header>

</template>

<script>

export default{

props:["title","count"]

}

</script>