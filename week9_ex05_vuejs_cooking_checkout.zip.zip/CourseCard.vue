<template>

<div class="card">

<h2>{{course.name}}</h2>

<p>{{course.chef}}</p>

<p>R{{course.price}}</p>

<p v-if="course.stock>0">

Available

</p>

<p v-else class="sold">

Sold Out

</p>

<button

@click="$emit('add-course')"

:disabled="course.stock===0"

>

Add to Cart

</button>

</div>

</template>

<script setup>

defineProps({
course:Object
})

defineEmits(["add-course"])

</script>