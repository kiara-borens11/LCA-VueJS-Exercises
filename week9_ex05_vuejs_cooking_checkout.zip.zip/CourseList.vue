<template>

<div class="catalogue">

<CourseCard
v-for="course in courses"
:key="course.id"
:course="course"
@add-course="$emit('add-course',course)"
/>

</div>

</template>

<script setup>

import CourseCard from "./CourseCard.vue"

defineProps({
courses:Array
})

defineEmits(["add-course"])

</script>