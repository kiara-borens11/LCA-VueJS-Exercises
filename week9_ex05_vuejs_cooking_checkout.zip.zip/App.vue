<template>

<div class="container">

<h1>Cooking Masterclass Checkout</h1>

<div class="layout">

<CourseList
:courses="courses"
@add-course="addToCart"
/>

<Cart
:cart="cart"
@increase="increaseQty"
@decrease="decreaseQty"
@remove="removeItem"
/>

</div>

</div>

</template>

<script setup>

import { ref } from "vue"
import CourseList from "./components/CourseList.vue"
import Cart from "./components/Cart.vue"

const courses = ref([
{
id:1,
name:"Italian Pasta",
chef:"Chef Marco",
price:450,
stock:5
},
{
id:2,
name:"French Pastry",
chef:"Chef Claire",
price:600,
stock:2
},
{
id:3,
name:"Sushi Fundamentals",
chef:"Chef Kenji",
price:550,
stock:0
}
])

const cart = ref([])

function addToCart(course){

const existing = cart.value.find(c=>c.id===course.id)

if(existing){

existing.qty++

}else{

cart.value.push({
...course,
qty:1
})

}

}

function increaseQty(id){

const item=cart.value.find(c=>c.id===id)

item.qty++

}

function decreaseQty(id){

const item=cart.value.find(c=>c.id===id)

if(item.qty>1){

item.qty--

}

}

function removeItem(id){

cart.value=cart.value.filter(c=>c.id!==id)

}

</script>