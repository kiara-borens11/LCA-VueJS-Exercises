<template>

<div class="cart">

<h2>Shopping Cart</h2>

<div v-if="cart.length==0">

Cart is empty.

</div>

<CartItem

v-for="item in cart"

:key="item.id"

:item="item"

@increase="$emit('increase',item.id)"
@decrease="$emit('decrease',item.id)"
@remove="$emit('remove',item.id)"

/>

<PriceSummary :cart="cart"/>

</div>

</template>

<script setup>

import CartItem from "./CartItem.vue"
import PriceSummary from "./PriceSummary.vue"

defineProps({
cart:Array
})

defineEmits([
"increase",
"decrease",
"remove"
])

</script>