<template>

<div>

<h3>Summary</h3>

<p>

Subtotal:

R{{subtotal}}

</p>

<p>

Tax (15%):

R{{tax.toFixed(2)}}

</p>

<h2>

Total:

R{{total.toFixed(2)}}

</h2>

</div>

</template>

<script setup>

import {computed} from "vue"

const props=defineProps({
cart:Array
})

const subtotal=computed(()=>{

return props.cart.reduce((sum,item)=>{

return sum+item.price*item.qty

},0)

})

const tax=computed(()=>subtotal.value*0.15)

const total=computed(()=>subtotal.value+tax.value)

</script>