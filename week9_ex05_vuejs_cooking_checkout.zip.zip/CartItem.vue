<template>

<div class="item">

<h3>{{item.name}}</h3>

<p>R{{item.price}}</p>

<button @click="$emit('decrease')">-</button>

{{item.qty}}

<button @click="$emit('increase')">+</button>

<p>

Total:

R{{item.qty*item.price}}

</p>

<button @click="$emit('remove')">

Remove

</button>

</div>

</template>

<script setup>

defineProps({
item:Object
})

defineEmits([
"increase",
"decrease",
"remove"
])

</script>